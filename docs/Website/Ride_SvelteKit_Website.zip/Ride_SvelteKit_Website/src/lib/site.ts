/**
 * Central launch configuration.
 * Replace every placeholder before deploying the public site.
 * Do not publish a placeholder privacy policy or deletion contact.
 */
export const site = {
  brand: 'Ride',
  descriptor: 'Everyday mobility, local commerce and delivery',
  siteUrl: 'https://YOUR-RIDE-DOMAIN.com',
  supportEmail: 'support@YOUR-RIDE-DOMAIN.com',
  privacyEmail: 'privacy@YOUR-RIDE-DOMAIN.com',
  legalEntity: '[LEGAL COMPANY / DEVELOPER NAME]',
  businessAddress: '[REGISTERED BUSINESS ADDRESS]',
  playStoreUrl: '',
  appStoreUrl: '',
  lastUpdated: '5 November 2026',
  /** Set true only after the live app, SDKs, backend and retention rules are audited. */
  privacyPolicyApproved: false,
  /** Set true only after the email inbox and deletion workflow have been tested. */
  deletionWorkflowApproved: false
} as const;

export function isPlaceholder(value: string): boolean {
  return !value || /YOUR-|\[.*\]|example\.com/i.test(value);
}

export const supportEmailConfigured = !isPlaceholder(site.supportEmail);
export const privacyEmailConfigured = !isPlaceholder(site.privacyEmail);
export const companyConfigured = !isPlaceholder(site.legalEntity);
export const domainConfigured = !isPlaceholder(site.siteUrl);
export const playStoreConfigured = Boolean(site.playStoreUrl && site.playStoreUrl.startsWith('https://'));
